#ifndef CLICKTOFOCUS_H

#define CLICKTOFOCUS_H

#include "twm.h"
#include "iconmgr.h"
#include "workmgr.h"

void set_last_window();

#endif
