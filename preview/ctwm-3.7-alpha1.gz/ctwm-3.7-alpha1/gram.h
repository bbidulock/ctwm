#ifndef YY_parse_h_included
#define YY_parse_h_included
/*#define YY_USE_CLASS 
*/
#line 1 "/usr/share/bison++/bison.h"
/* before anything */
#ifdef c_plusplus
 #ifndef __cplusplus
  #define __cplusplus
 #endif
#endif


 #line 8 "/usr/share/bison++/bison.h"

#line 121 "gram.y"
typedef union
{
    int num;
    unsigned char *ptr;
} yy_parse_stype;
#define YY_parse_STYPE yy_parse_stype
#ifndef YY_USE_CLASS
#define YYSTYPE yy_parse_stype
#endif

#line 21 "/usr/share/bison++/bison.h"
 /* %{ and %header{ and %union, during decl */
#ifndef YY_parse_COMPATIBILITY
 #ifndef YY_USE_CLASS
  #define  YY_parse_COMPATIBILITY 1
 #else
  #define  YY_parse_COMPATIBILITY 0
 #endif
#endif

#if YY_parse_COMPATIBILITY != 0
/* backward compatibility */
 #ifdef YYLTYPE
  #ifndef YY_parse_LTYPE
   #define YY_parse_LTYPE YYLTYPE
/* WARNING obsolete !!! user defined YYLTYPE not reported into generated header */
/* use %define LTYPE */
  #endif
 #endif
/*#ifdef YYSTYPE*/
  #ifndef YY_parse_STYPE
   #define YY_parse_STYPE YYSTYPE
  /* WARNING obsolete !!! user defined YYSTYPE not reported into generated header */
   /* use %define STYPE */
  #endif
/*#endif*/
 #ifdef YYDEBUG
  #ifndef YY_parse_DEBUG
   #define  YY_parse_DEBUG YYDEBUG
   /* WARNING obsolete !!! user defined YYDEBUG not reported into generated header */
   /* use %define DEBUG */
  #endif
 #endif 
 /* use goto to be compatible */
 #ifndef YY_parse_USE_GOTO
  #define YY_parse_USE_GOTO 1
 #endif
#endif

/* use no goto to be clean in C++ */
#ifndef YY_parse_USE_GOTO
 #define YY_parse_USE_GOTO 0
#endif

#ifndef YY_parse_PURE

 #line 65 "/usr/share/bison++/bison.h"

#line 65 "/usr/share/bison++/bison.h"
/* YY_parse_PURE */
#endif


 #line 68 "/usr/share/bison++/bison.h"

#line 68 "/usr/share/bison++/bison.h"
/* prefix */

#ifndef YY_parse_DEBUG

 #line 71 "/usr/share/bison++/bison.h"

#line 71 "/usr/share/bison++/bison.h"
/* YY_parse_DEBUG */
#endif

#ifndef YY_parse_LSP_NEEDED

 #line 75 "/usr/share/bison++/bison.h"

#line 75 "/usr/share/bison++/bison.h"
 /* YY_parse_LSP_NEEDED*/
#endif

/* DEFAULT LTYPE*/
#ifdef YY_parse_LSP_NEEDED
 #ifndef YY_parse_LTYPE
  #ifndef BISON_YYLTYPE_ISDECLARED
   #define BISON_YYLTYPE_ISDECLARED
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;
  #endif

  #define YY_parse_LTYPE yyltype
 #endif
#endif

/* DEFAULT STYPE*/
#ifndef YY_parse_STYPE
 #define YY_parse_STYPE int
#endif

/* DEFAULT MISCELANEOUS */
#ifndef YY_parse_PARSE
 #define YY_parse_PARSE yyparse
#endif

#ifndef YY_parse_LEX
 #define YY_parse_LEX yylex
#endif

#ifndef YY_parse_LVAL
 #define YY_parse_LVAL yylval
#endif

#ifndef YY_parse_LLOC
 #define YY_parse_LLOC yylloc
#endif

#ifndef YY_parse_CHAR
 #define YY_parse_CHAR yychar
#endif

#ifndef YY_parse_NERRS
 #define YY_parse_NERRS yynerrs
#endif

#ifndef YY_parse_DEBUG_FLAG
 #define YY_parse_DEBUG_FLAG yydebug
#endif

#ifndef YY_parse_ERROR
 #define YY_parse_ERROR yyerror
#endif

#ifndef YY_parse_PARSE_PARAM
 #ifndef __STDC__
  #ifndef __cplusplus
   #ifndef YY_USE_CLASS
    #define YY_parse_PARSE_PARAM
    #ifndef YY_parse_PARSE_PARAM_DEF
     #define YY_parse_PARSE_PARAM_DEF
    #endif
   #endif
  #endif
 #endif
 #ifndef YY_parse_PARSE_PARAM
  #define YY_parse_PARSE_PARAM void
 #endif
#endif

/* TOKEN C */
#ifndef YY_USE_CLASS

 #ifndef YY_parse_PURE
  #ifndef yylval
   extern YY_parse_STYPE YY_parse_LVAL;
  #else
   #if yylval != YY_parse_LVAL
    extern YY_parse_STYPE YY_parse_LVAL;
   #else
    #warning "Namespace conflict, disabling some functionality (bison++ only)"
   #endif
  #endif
 #endif


 #line 169 "/usr/share/bison++/bison.h"
#define	LB	258
#define	RB	259
#define	LP	260
#define	RP	261
#define	MENUS	262
#define	MENU	263
#define	BUTTON	264
#define	DEFAULT_FUNCTION	265
#define	PLUS	266
#define	MINUS	267
#define	ALL	268
#define	OR	269
#define	CURSORS	270
#define	PIXMAPS	271
#define	ICONS	272
#define	COLOR	273
#define	SAVECOLOR	274
#define	MONOCHROME	275
#define	FUNCTION	276
#define	ICONMGR_SHOW	277
#define	ICONMGR	278
#define	ALTER	279
#define	WINDOW_FUNCTION	280
#define	ZOOM	281
#define	ICONMGRS	282
#define	ICONMGR_GEOMETRY	283
#define	ICONMGR_NOSHOW	284
#define	MAKE_TITLE	285
#define	ICONIFY_BY_UNMAPPING	286
#define	DONT_ICONIFY_BY_UNMAPPING	287
#define	NO_BORDER	288
#define	NO_ICON_TITLE	289
#define	NO_TITLE	290
#define	AUTO_RAISE	291
#define	NO_HILITE	292
#define	ICON_REGION	293
#define	WINDOW_REGION	294
#define	META	295
#define	SHIFT	296
#define	LOCK	297
#define	CONTROL	298
#define	WINDOW	299
#define	TITLE	300
#define	ICON	301
#define	ROOT	302
#define	FRAME	303
#define	COLON	304
#define	EQUALS	305
#define	SQUEEZE_TITLE	306
#define	DONT_SQUEEZE_TITLE	307
#define	START_ICONIFIED	308
#define	NO_TITLE_HILITE	309
#define	TITLE_HILITE	310
#define	MOVE	311
#define	RESIZE	312
#define	WAITC	313
#define	SELECT	314
#define	KILL	315
#define	LEFT_TITLEBUTTON	316
#define	RIGHT_TITLEBUTTON	317
#define	NUMBER	318
#define	KEYWORD	319
#define	NKEYWORD	320
#define	CKEYWORD	321
#define	CLKEYWORD	322
#define	FKEYWORD	323
#define	FSKEYWORD	324
#define	SKEYWORD	325
#define	DKEYWORD	326
#define	JKEYWORD	327
#define	WINDOW_RING	328
#define	WINDOW_RING_EXCLUDE	329
#define	WARP_CURSOR	330
#define	ERRORTOKEN	331
#define	NO_STACKMODE	332
#define	ALWAYS_ON_TOP	333
#define	WORKSPACE	334
#define	WORKSPACES	335
#define	WORKSPCMGR_GEOMETRY	336
#define	OCCUPYALL	337
#define	OCCUPYLIST	338
#define	MAPWINDOWCURRENTWORKSPACE	339
#define	MAPWINDOWDEFAULTWORKSPACE	340
#define	UNMAPBYMOVINGFARAWAY	341
#define	OPAQUEMOVE	342
#define	NOOPAQUEMOVE	343
#define	OPAQUERESIZE	344
#define	NOOPAQUERESIZE	345
#define	DONTSETINACTIVE	346
#define	CHANGE_WORKSPACE_FUNCTION	347
#define	DEICONIFY_FUNCTION	348
#define	ICONIFY_FUNCTION	349
#define	AUTOSQUEEZE	350
#define	STARTSQUEEZED	351
#define	DONT_SAVE	352
#define	AUTO_LOWER	353
#define	ICONMENU_DONTSHOW	354
#define	WINDOW_BOX	355
#define	IGNOREMODIFIER	356
#define	WINDOW_GEOMETRIES	357
#define	ALWAYSSQUEEZETOGRAVITY	358
#define	VIRTUAL_SCREENS	359
#define	STRING	360


#line 169 "/usr/share/bison++/bison.h"
 /* #defines token */
/* after #define tokens, before const tokens S5*/
#else
 #ifndef YY_parse_CLASS
  #define YY_parse_CLASS parse
 #endif

 #ifndef YY_parse_INHERIT
  #define YY_parse_INHERIT
 #endif

 #ifndef YY_parse_MEMBERS
  #define YY_parse_MEMBERS 
 #endif

 #ifndef YY_parse_LEX_BODY
  #define YY_parse_LEX_BODY  
 #endif

 #ifndef YY_parse_ERROR_BODY
  #define YY_parse_ERROR_BODY  
 #endif

 #ifndef YY_parse_CONSTRUCTOR_PARAM
  #define YY_parse_CONSTRUCTOR_PARAM
 #endif
 /* choose between enum and const */
 #ifndef YY_parse_USE_CONST_TOKEN
  #define YY_parse_USE_CONST_TOKEN 0
  /* yes enum is more compatible with flex,  */
  /* so by default we use it */ 
 #endif
 #if YY_parse_USE_CONST_TOKEN != 0
  #ifndef YY_parse_ENUM_TOKEN
   #define YY_parse_ENUM_TOKEN yy_parse_enum_token
  #endif
 #endif

class YY_parse_CLASS YY_parse_INHERIT
{
public: 
 #if YY_parse_USE_CONST_TOKEN != 0
  /* static const int token ... */
  
 #line 212 "/usr/share/bison++/bison.h"
static const int LB;
static const int RB;
static const int LP;
static const int RP;
static const int MENUS;
static const int MENU;
static const int BUTTON;
static const int DEFAULT_FUNCTION;
static const int PLUS;
static const int MINUS;
static const int ALL;
static const int OR;
static const int CURSORS;
static const int PIXMAPS;
static const int ICONS;
static const int COLOR;
static const int SAVECOLOR;
static const int MONOCHROME;
static const int FUNCTION;
static const int ICONMGR_SHOW;
static const int ICONMGR;
static const int ALTER;
static const int WINDOW_FUNCTION;
static const int ZOOM;
static const int ICONMGRS;
static const int ICONMGR_GEOMETRY;
static const int ICONMGR_NOSHOW;
static const int MAKE_TITLE;
static const int ICONIFY_BY_UNMAPPING;
static const int DONT_ICONIFY_BY_UNMAPPING;
static const int NO_BORDER;
static const int NO_ICON_TITLE;
static const int NO_TITLE;
static const int AUTO_RAISE;
static const int NO_HILITE;
static const int ICON_REGION;
static const int WINDOW_REGION;
static const int META;
static const int SHIFT;
static const int LOCK;
static const int CONTROL;
static const int WINDOW;
static const int TITLE;
static const int ICON;
static const int ROOT;
static const int FRAME;
static const int COLON;
static const int EQUALS;
static const int SQUEEZE_TITLE;
static const int DONT_SQUEEZE_TITLE;
static const int START_ICONIFIED;
static const int NO_TITLE_HILITE;
static const int TITLE_HILITE;
static const int MOVE;
static const int RESIZE;
static const int WAITC;
static const int SELECT;
static const int KILL;
static const int LEFT_TITLEBUTTON;
static const int RIGHT_TITLEBUTTON;
static const int NUMBER;
static const int KEYWORD;
static const int NKEYWORD;
static const int CKEYWORD;
static const int CLKEYWORD;
static const int FKEYWORD;
static const int FSKEYWORD;
static const int SKEYWORD;
static const int DKEYWORD;
static const int JKEYWORD;
static const int WINDOW_RING;
static const int WINDOW_RING_EXCLUDE;
static const int WARP_CURSOR;
static const int ERRORTOKEN;
static const int NO_STACKMODE;
static const int ALWAYS_ON_TOP;
static const int WORKSPACE;
static const int WORKSPACES;
static const int WORKSPCMGR_GEOMETRY;
static const int OCCUPYALL;
static const int OCCUPYLIST;
static const int MAPWINDOWCURRENTWORKSPACE;
static const int MAPWINDOWDEFAULTWORKSPACE;
static const int UNMAPBYMOVINGFARAWAY;
static const int OPAQUEMOVE;
static const int NOOPAQUEMOVE;
static const int OPAQUERESIZE;
static const int NOOPAQUERESIZE;
static const int DONTSETINACTIVE;
static const int CHANGE_WORKSPACE_FUNCTION;
static const int DEICONIFY_FUNCTION;
static const int ICONIFY_FUNCTION;
static const int AUTOSQUEEZE;
static const int STARTSQUEEZED;
static const int DONT_SAVE;
static const int AUTO_LOWER;
static const int ICONMENU_DONTSHOW;
static const int WINDOW_BOX;
static const int IGNOREMODIFIER;
static const int WINDOW_GEOMETRIES;
static const int ALWAYSSQUEEZETOGRAVITY;
static const int VIRTUAL_SCREENS;
static const int STRING;


#line 212 "/usr/share/bison++/bison.h"
 /* decl const */
 #else
  enum YY_parse_ENUM_TOKEN { YY_parse_NULL_TOKEN=0
  
 #line 215 "/usr/share/bison++/bison.h"
	,LB=258
	,RB=259
	,LP=260
	,RP=261
	,MENUS=262
	,MENU=263
	,BUTTON=264
	,DEFAULT_FUNCTION=265
	,PLUS=266
	,MINUS=267
	,ALL=268
	,OR=269
	,CURSORS=270
	,PIXMAPS=271
	,ICONS=272
	,COLOR=273
	,SAVECOLOR=274
	,MONOCHROME=275
	,FUNCTION=276
	,ICONMGR_SHOW=277
	,ICONMGR=278
	,ALTER=279
	,WINDOW_FUNCTION=280
	,ZOOM=281
	,ICONMGRS=282
	,ICONMGR_GEOMETRY=283
	,ICONMGR_NOSHOW=284
	,MAKE_TITLE=285
	,ICONIFY_BY_UNMAPPING=286
	,DONT_ICONIFY_BY_UNMAPPING=287
	,NO_BORDER=288
	,NO_ICON_TITLE=289
	,NO_TITLE=290
	,AUTO_RAISE=291
	,NO_HILITE=292
	,ICON_REGION=293
	,WINDOW_REGION=294
	,META=295
	,SHIFT=296
	,LOCK=297
	,CONTROL=298
	,WINDOW=299
	,TITLE=300
	,ICON=301
	,ROOT=302
	,FRAME=303
	,COLON=304
	,EQUALS=305
	,SQUEEZE_TITLE=306
	,DONT_SQUEEZE_TITLE=307
	,START_ICONIFIED=308
	,NO_TITLE_HILITE=309
	,TITLE_HILITE=310
	,MOVE=311
	,RESIZE=312
	,WAITC=313
	,SELECT=314
	,KILL=315
	,LEFT_TITLEBUTTON=316
	,RIGHT_TITLEBUTTON=317
	,NUMBER=318
	,KEYWORD=319
	,NKEYWORD=320
	,CKEYWORD=321
	,CLKEYWORD=322
	,FKEYWORD=323
	,FSKEYWORD=324
	,SKEYWORD=325
	,DKEYWORD=326
	,JKEYWORD=327
	,WINDOW_RING=328
	,WINDOW_RING_EXCLUDE=329
	,WARP_CURSOR=330
	,ERRORTOKEN=331
	,NO_STACKMODE=332
	,ALWAYS_ON_TOP=333
	,WORKSPACE=334
	,WORKSPACES=335
	,WORKSPCMGR_GEOMETRY=336
	,OCCUPYALL=337
	,OCCUPYLIST=338
	,MAPWINDOWCURRENTWORKSPACE=339
	,MAPWINDOWDEFAULTWORKSPACE=340
	,UNMAPBYMOVINGFARAWAY=341
	,OPAQUEMOVE=342
	,NOOPAQUEMOVE=343
	,OPAQUERESIZE=344
	,NOOPAQUERESIZE=345
	,DONTSETINACTIVE=346
	,CHANGE_WORKSPACE_FUNCTION=347
	,DEICONIFY_FUNCTION=348
	,ICONIFY_FUNCTION=349
	,AUTOSQUEEZE=350
	,STARTSQUEEZED=351
	,DONT_SAVE=352
	,AUTO_LOWER=353
	,ICONMENU_DONTSHOW=354
	,WINDOW_BOX=355
	,IGNOREMODIFIER=356
	,WINDOW_GEOMETRIES=357
	,ALWAYSSQUEEZETOGRAVITY=358
	,VIRTUAL_SCREENS=359
	,STRING=360


#line 215 "/usr/share/bison++/bison.h"
 /* enum token */
     }; /* end of enum declaration */
 #endif
public:
 int YY_parse_PARSE(YY_parse_PARSE_PARAM);
 virtual void YY_parse_ERROR(char *msg) YY_parse_ERROR_BODY;
 #ifdef YY_parse_PURE
  #ifdef YY_parse_LSP_NEEDED
   virtual int  YY_parse_LEX(YY_parse_STYPE *YY_parse_LVAL,YY_parse_LTYPE *YY_parse_LLOC) YY_parse_LEX_BODY;
  #else
   virtual int  YY_parse_LEX(YY_parse_STYPE *YY_parse_LVAL) YY_parse_LEX_BODY;
  #endif
 #else
  virtual int YY_parse_LEX() YY_parse_LEX_BODY;
  YY_parse_STYPE YY_parse_LVAL;
  #ifdef YY_parse_LSP_NEEDED
   YY_parse_LTYPE YY_parse_LLOC;
  #endif
  int YY_parse_NERRS;
  int YY_parse_CHAR;
 #endif
 #if YY_parse_DEBUG != 0
  public:
   int YY_parse_DEBUG_FLAG;	/*  nonzero means print parse trace	*/
 #endif
public:
 YY_parse_CLASS(YY_parse_CONSTRUCTOR_PARAM);
public:
 YY_parse_MEMBERS 
};
/* other declare folow */
#endif


#if YY_parse_COMPATIBILITY != 0
 /* backward compatibility */
 /* Removed due to bison problems
 /#ifndef YYSTYPE
 / #define YYSTYPE YY_parse_STYPE
 /#endif*/

 #ifndef YYLTYPE
  #define YYLTYPE YY_parse_LTYPE
 #endif
 #ifndef YYDEBUG
  #ifdef YY_parse_DEBUG 
   #define YYDEBUG YY_parse_DEBUG
  #endif
 #endif

#endif
/* END */

 #line 267 "/usr/share/bison++/bison.h"
#endif
