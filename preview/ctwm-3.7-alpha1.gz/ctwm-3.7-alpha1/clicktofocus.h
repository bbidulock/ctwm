#ifndef CLICKTOFOCUS_H

#define CLICKTOFOCUS_H

#include "twm.h"
#include "iconmgr.h"

void set_last_window();

#endif
